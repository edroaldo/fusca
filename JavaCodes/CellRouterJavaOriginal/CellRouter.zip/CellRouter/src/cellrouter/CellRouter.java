/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cellrouter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.PosixParser;


/**
 *
 * @author edroaldo
 * 
 */
public class CellRouter {
    private CommandLine cmd = null;
    private Options options = null;
    
    private String file;
    //private String fileHGNC;
    
    public boolean checkArgs(String args[]){
        try{
            options = new Options();
            options.addOption("NET", true, "edge-weigthed network");
            
            options.addOption("C", false, "Create flow network");
            options.addOption("source", true, "source");
            options.addOption("sink", true, "sink");
            options.addOption("topPaths", true, "include only the top paths with the lowest cost");
            options.addOption("out", true, "Output folder");
            options.addOption("f", true, "filename");
            
            CommandLineParser parser = new PosixParser();
            this.cmd = parser.parse(options, args);

            return true;
        }catch(Exception e){
            System.err.println(e.getMessage());
            System.exit(1);
        }
        return false;
    }
    
    public void runAnalysis() throws Exception, IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        file = cmd.getOptionValue("NET");
        
        if(cmd.hasOption("C")){
            createFlowNetwork();
            System.exit(0);
        }
    }
    
    public void createFlowNetwork() throws IOException{
        System.out.println("Creating flow network...");
        String filename = cmd.getOptionValue("f");
        String dir = cmd.getOptionValue("out");
        int top = Integer.valueOf(cmd.getOptionValue("topPaths"));
        
        String cellSources = cmd.getOptionValue("source");
        String cellSinks = cmd.getOptionValue("sink");
        Set<String> sourceCells = new LinkedHashSet(CellRouterUtils.getSourcesSinks(cellSources));
        Set<String> sinkCells = new LinkedHashSet(CellRouterUtils.getSourcesSinks(cellSinks));
        
        //Node source = new Node(cmd.getOptionValue("source"));
        //Node sink = new Node(cmd.getOptionValue("sink"));
        NetworkFlow net = new NetworkFlow();
        InputOutput io = new InputOutput();
        io.getNetworkData(file);
        
        List<Double> weigths = io.getWeights();
        Map<Integer, Map<String, Edge>> allPathsNet = new LinkedHashMap();
        Map<String, Node> network = new LinkedHashMap();
     
        //source.setSymbol(source.getName());
        //sink.setSymbol(sink.getName());
        //System.out.println(source);
        //System.out.println(sink);
        List<Node> sources = new ArrayList();
        List<Node> sinks = new ArrayList();
        for(String s: sourceCells){
            Node tmp = new Node(s);
            tmp.setSymbol(s);
            sources.add(tmp);
        }
        for(String s: sinkCells){
            Node tmp = new Node(s);
            tmp.setSymbol(s);
            sinks.add(tmp);
        }
        
        net.createNetwork(sources, sinks, network, io.getFrom(), io.getTo(), weigths);
        net.mappingNameToId(network);
        net.compute(network, allPathsNet);
        Map<String, Node> subnet = new LinkedHashMap();
        Map<Integer, List<Edge>> pathsSubnet = net.buildSubnet(network, //revise this function...
                subnet, allPathsNet);
        
        List<String> pathsFlow = new ArrayList();
        for (Integer path : pathsSubnet.keySet()) {
            String pathFlowAsString = CellRouterUtils.convertPath2String(pathsSubnet.get(path), true);
            pathsFlow.add(pathFlowAsString);
        }
        String pathsName = filename + "_paths.ser";
        Serialization.serialize(pathsFlow, dir + pathsName);
        
        List<Path> allPaths = CellRouterUtils.convertString2Paths(pathsFlow);
        //Collections.sort(allPaths, (Path p1, Path p2) -> Double.compare(p1.cost, p2.cost));
        Collections.sort(allPaths, (Path p1, Path p2) -> Double.compare(p1.flow, p2.flow));
        //Collections.sort(allPaths, Collections.reverseOrder());
        //List<Path> topPaths = allPaths.subList(0, 100);
        //List<Path> topPaths = allPaths.subList(0, top);
        //CellRouterUtils.savePaths(topPaths, filename + "_top_100_paths.txt");
        CellRouterUtils.savePaths(allPaths, filename + "_all_paths.txt");
        
        Map<String, Node> cellSubnet = CellRouterUtils.createNetworkFromPaths(CellRouterUtils.convertPaths2String(allPaths));
        Map<String, Double> cellFlows = CellRouterUtils.getTotalFlow(cellSubnet);
        
        //Map<String, Node> topPathsCellSubnet = CellRouterUtils.createNetworkFromPaths(CellRouterUtils.convertPaths2String(topPaths));
        //Map<String, Double> topPathsCellFlows = CellRouterUtils.getTotalFlow(topPathsCellSubnet);
        
        CellRouterUtils.saveSubNet(cellSubnet, filename+"_all_paths_subnet.txt");
        CellRouterUtils.saveFlows(cellFlows, filename + "_all_paths_totalFlow.txt");
        
        //CellRouterUtils.saveSubNet(topPathsCellSubnet, filename+"_top_paths_subnet.txt");
        //CellRouterUtils.saveFlows(topPathsCellFlows, filename + "_top_paths_totalFlow.txt");
        
        List<String> Rscripts = new ArrayList();
        //String topPathsSubnetGML = RJava.createScriptExportGML(filename+"_top_paths_subnet", filename + "_top_paths_totalFlow");
        String subnetGML = RJava.createScriptExportGML(filename+"_all_paths_subnet", filename + "_all_paths_totalFlow");
        //Rscripts.add(topPathsSubnetGML);
        Rscripts.add(subnetGML);
        
        String scriptName = filename + "_scripts" + ".R";
        CellRouterUtils.combineFiles(Rscripts, scriptName);
        try {
            Runtime.getRuntime().exec("R --slave --no-save CMD BATCH " + scriptName);
        } catch (IOException error) {
            System.out.println(error.getMessage());
        }
        
    }
    /*public void createFlowNetwork() throws IOException{
        System.out.println("Creating flow network...");
        String filename = cmd.getOptionValue("f");
        String dir = cmd.getOptionValue("out");
        
        Node source = new Node(cmd.getOptionValue("source"));
        Node sink = new Node(cmd.getOptionValue("sink"));
        NetworkFlow net = new NetworkFlow();
        InputOutput io = new InputOutput();
        io.getNetworkData(file);
        //Set<String> sourceGenes = null;//new LinkedHashSet(NetworkFlow.getGenes(geneListFile));
        List<Double> weigths = io.getWeights();
        Map<Integer, Map<String, Edge>> allPathsNet = new LinkedHashMap();
        Map<String, Node> network = new LinkedHashMap();
        //Set<String> sinks = null;//net.setUniversalSinksHuman(utils, TFAnnot, geneSymbol);
        
        //List<List<Node>> sourcesAndSinks = null;//net.selectSources(sourceGenes, sinks, io.getProteinsA(),io.getProteinsB());
        //List<Node> sources = sourcesAndSinks.get(0);
        //List<Node> sinkNodes = sourcesAndSinks.get(1);
        //Node source = new Node("GEN00027978");
        //Node sink = new Node("GEN00027996");
        //source.setSymbol("GEN00028049");
        //sink.setSymbol("GEN00028053");
        //Node source = new Node("ola_mES_lif_1_29");
        //Node sink  = new Node("ola_mES_lif_3_74");
        source.setSymbol(source.getName());
        sink.setSymbol(sink.getName());
        System.out.println(source);
        System.out.println(sink);
        List<Node> sources = new ArrayList();
        List<Node> sinks = new ArrayList();
        sources.add(source);
        sinks.add(sink);
        
        net.createNetwork(sources, sinks, network, io.getFrom(), io.getTo(), weigths);
        net.mappingNameToId(network);
        net.compute(network, allPathsNet);
        Map<String, Node> subnet = new LinkedHashMap();
        Map<Integer, List<Edge>> pathsSubnet = net.buildSubnet(network, //revise this function...
                subnet, allPathsNet);
        
        List<String> pathsFlow = new ArrayList();
        for (Integer path : pathsSubnet.keySet()) {
            String pathFlowAsString = CellRouterUtils.convertPath2String(pathsSubnet.get(path), true);
            pathsFlow.add(pathFlowAsString);
        }
        String pathsName = filename + "_paths.ser";
        Serialization.serialize(pathsFlow, dir + pathsName);
        
        List<Path> allPaths = CellRouterUtils.convertString2Paths(pathsFlow);
        Collections.sort(allPaths, (Path p1, Path p2) -> Double.compare(p1.cost, p2.cost));
        List<Path> topPaths = allPaths.subList(0, 100);
        CellRouterUtils.savePaths(topPaths, filename + "_top_100_paths.txt");
        CellRouterUtils.savePaths(allPaths, filename + "_all_paths.txt");
        
        Map<String, Node> cellSubnet = CellRouterUtils.createNetworkFromPaths(CellRouterUtils.convertPaths2String(allPaths));
        Map<String, Double> cellFlows = CellRouterUtils.getTotalFlow(cellSubnet);
        
        Map<String, Node> topPathsCellSubnet = CellRouterUtils.createNetworkFromPaths(CellRouterUtils.convertPaths2String(topPaths));
        Map<String, Double> topPathsCellFlows = CellRouterUtils.getTotalFlow(topPathsCellSubnet);
        
        CellRouterUtils.saveSubNet(cellSubnet, filename+"_all_paths_subnet.txt");
        CellRouterUtils.saveFlows(cellFlows, filename + "_all_paths_totalFlow.txt");
        
        CellRouterUtils.saveSubNet(topPathsCellSubnet, filename+"_top_paths_subnet.txt");
        CellRouterUtils.saveFlows(topPathsCellFlows, filename + "_top_paths_totalFlow.txt");
        
        List<String> Rscripts = new ArrayList();
        String topPathsSubnetGML = RJava.createScriptExportGML(filename+"_top_paths_subnet", filename + "_top_paths_totalFlow");
        String subnetGML = RJava.createScriptExportGML(filename+"_all_paths_subnet", filename + "_all_paths_totalFlow");
        Rscripts.add(topPathsSubnetGML);
        Rscripts.add(subnetGML);
        
        String scriptName = filename + "_scripts" + ".R";
        CellRouterUtils.combineFiles(Rscripts, scriptName);
        try {
            Runtime.getRuntime().exec("R --slave --no-save CMD BATCH " + scriptName);
        } catch (IOException error) {
            System.out.println(error.getMessage());
        }
        
    }*/
    
    public static void main(String[] args) throws IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException{
    	try {
            CellRouter pn = new CellRouter();
            if(pn.checkArgs(args)){
                pn.runAnalysis();
            }else{
                System.out.println("ferrou");
            }
    	}
    	catch (Throwable t) {
    		System.err.println("Uncaught exception - " + t.getMessage());
            t.printStackTrace(System.err);
    	}
    }
 
    
    /*
    public void edgeAnalysis() throws IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        String dir = cmd.getOptionValue("out");
        //String d = cmd.getOptionValue("d");
        String filename = cmd.getOptionValue("f");
        String ncp = cmd.getOptionValue("ncp");
        String ndp = cmd.getOptionValue("ndp");
        String control = cmd.getOptionValue("control");
        String condition = cmd.getOptionValue("condition");
        Double corThreshold = Double.valueOf(cmd.getOptionValue("corThreshold"));
        Double ratioThreshold = Double.valueOf(cmd.getOptionValue("ratioThreshold"));
        Integer top = Integer.valueOf(cmd.getOptionValue("top"));
        RJava rJava = new RJava();
        
        String geneListFile = cmd.getOptionValue("g");
        Set<String> genesPaths = null;
        if(!geneListFile.equals("none")){
            genesPaths = new LinkedHashSet(NetworkFlow.getGenes(geneListFile));
        }
        List<String> controlNetworkPaths = Serialization.deserialize(ncp, List.class);
        List<String> diseaseNetworkPaths = Serialization.deserialize(ndp, List.class);
        Map<String, Node> controlNetwork = createNetworkFromPaths(controlNetworkPaths);
        Map<String, Node> diseaseNetwork = createNetworkFromPaths(diseaseNetworkPaths);
        
        Map<String, Map<String, Double>> flowInNetworks = getFlowInNetworks(controlNetwork, diseaseNetwork);
        Map<String, Double> totalFlowsDisease = CellRouterUtils.getTotalFlow(diseaseNetwork);
        Map<String, Double> totalFlowsControl = CellRouterUtils.getTotalFlow(controlNetwork);
        
        Set<Edge> cEdges = getAllEdges(controlNetwork);
        Set<Edge> dEdges = getAllEdges(diseaseNetwork);
        Map<String, Map<String, Double>> flowMatrix = new LinkedHashMap();
        
        if(!cmd.hasOption("overlap")){ //use only edges in both networks to infer key edges?
            dEdges.addAll(cEdges);
        }else{
            dEdges.retainAll(cEdges);
        }
        Map<String, Double> xxControl = new LinkedHashMap();
        Map<String, Double> xxDisease = new LinkedHashMap();
        for(Edge e:dEdges){
            Edge eControl = CellRouterUtils.getEdge(controlNetwork, e);
            Edge eDisease = CellRouterUtils.getEdge(diseaseNetwork, e);
            //System.out.println(eDisease.getFlow() + "\t" + eDisease.getSignScores());
            if(eControl != null && eDisease != null){
                xxControl.put(e.toString(), eControl.getFlow());
                xxDisease.put(e.toString(), eDisease.getFlow());
            }else if(eControl != null){
                xxControl.put(e.toString(), eControl.getFlow());
                xxDisease.put(e.toString(), 0.0);
            }else if(eDisease != null){
                xxControl.put(e.toString(), 0.0);
                xxDisease.put(e.toString(), eDisease.getFlow());
            }
        }
        flowMatrix.put(control, xxControl);
        flowMatrix.put(condition, xxDisease);
        
        //creating folders...
        String path2create = dir + condition + "/";
        new File(path2create).mkdirs();
        
        Map<String, Map<String, Double>> aux = changeMapping(flowMatrix);
        String name = path2create + filename+"_flowMatrix";
        saveFlowMatrix(aux, control, condition, name+".txt");
        
        List<String> Rscripts = new ArrayList();
        //rJava.plotBarplot(path2create, name, condition, corThreshold, ratioThreshold, filename);
        String barplot = rJava.createBarplotScript(path2create, name, condition, corThreshold, ratioThreshold, filename);
        //Rscripts.add(barplot);
 
        try {
            TimeUnit.SECONDS.sleep(5);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
        //Load key edges flow matrix for differential edge-centered network enrichment
        String keyEdgesFile = path2create + filename + "_keyEdges.txt";
        System.out.println(keyEdgesFile);
        Set<Edge> keyEdges = loadKeyEdges(keyEdgesFile);
        
        //==========save full networks
        CellRouterUtils.savePaths(CellRouterUtils.convertString2Paths(diseaseNetworkPaths), condition + "/" + filename + "_ALL_paths_disease.txt");
        CellRouterUtils.savePaths(CellRouterUtils.convertString2Paths(controlNetworkPaths), condition + "/" + filename + "_ALL_paths_control.txt");
        Map<String, Double> controlDFNdiff = getFlowDifference(flowInNetworks, controlNetwork.keySet());
        Map<String, Double> diseaseDFNdiff = getFlowDifference(flowInNetworks, diseaseNetwork.keySet());
        Map<String, Double> controlDFNtotal = getTotalFlowInProteins(totalFlowsControl, controlNetwork.keySet());
        Map<String, Double> diseaseDFNtotal = getTotalFlowInProteins(totalFlowsDisease, diseaseNetwork.keySet());
        CellRouterUtils.saveFlows(controlDFNtotal, dir + "/" + condition + "/" + filename + "_FULL_totalFlow_Control.txt");
        CellRouterUtils.saveFlows(diseaseDFNtotal, condition + "/" +filename + "_FULL_totalFlow_Disease.txt");
        CellRouterUtils.saveFlows(controlDFNdiff, condition + "/" +filename + "_FULL_flowDifference_Control.txt");
        CellRouterUtils.saveFlows(diseaseDFNdiff, condition + "/" +filename + "_FULL_flowDifference_Disease.txt");
        CellRouterUtils.saveGeneList(controlNetwork, condition + "/" +filename + "_FULL_GENES_Control.txt");
        CellRouterUtils.saveGeneList(diseaseNetwork, condition + "/" +filename + "_FULL_GENES_Disease.txt");
        (new NetworkFlow()).saveSubNet(controlNetwork, condition + "/" +filename+"_FULL_Control.txt");
        (new NetworkFlow()).saveSubNet(diseaseNetwork, condition + "/" +filename+"_FULL_Disease.txt");
        
        //rJava.exportGML(condition + "/" +filename+"_FULL_Control", condition + "/" +filename + "_FULL_totalFlow_Control", 
        //        condition + "/" +filename + "_FULL_flowDifference_Control");
        //rJava.exportGML(condition + "/" +filename+"_FULL_Disease", condition + "/" +filename + "_FULL_totalFlow_Disease", 
        //        condition + "/" + filename + "_FULL_flowDifference_Disease");
        
        String gmlControl = rJava.createScriptExportGML(condition + "/" +filename+"_FULL_Control", condition + "/" +filename + "_FULL_totalFlow_Control", 
                condition + "/" +filename + "_FULL_flowDifference_Control");
        String gmlDisease = rJava.createScriptExportGML(condition + "/" +filename+"_FULL_Disease", condition + "/" +filename + "_FULL_totalFlow_Disease", 
                condition + "/" + filename + "_FULL_flowDifference_Disease");
        Rscripts.add(gmlControl);
        Rscripts.add(gmlDisease);
        //===========
        //Now have to extract paths containing key edges
        Map<Edge, List<Path>> diseaseEdges2Path = CellRouterUtils.getPathsFromEdges(diseaseNetworkPaths, keyEdges);
        Map<Edge, List<Path>> controlEdges2Path = CellRouterUtils.getPathsFromEdges(controlNetworkPaths, keyEdges);

        String name_2 = path2create + filename + "_" + control + "_" + condition;
        CellRouterUtils.comparePaths(diseaseEdges2Path, controlEdges2Path,
                totalFlowsDisease, totalFlowsControl, flowInNetworks,
                rJava, condition, genesPaths, name_2, path2create, Rscripts);
        
        System.out.println("Saving key targets");
        Set<String> sinks = prioritizeSinks(controlNetwork, diseaseNetwork, condition, top, rJava, name_2, Rscripts);
        System.out.println("Saving Network routers");
        Set<String> hidden = prioritizeHiddenProteins(controlNetwork, diseaseNetwork, condition, top, rJava, name_2, Rscripts);
        Set<String> IPgenes = computeImpactScore(controlNetwork, diseaseNetwork).keySet();
        prioritizePaths(controlNetworkPaths, diseaseNetworkPaths, totalFlowsDisease, flowInNetworks,
                sinks, hidden, IPgenes, rJava, name_2, Rscripts);
        
        String scriptName = filename + "_combinedScript" + ".R";
        CellRouterUtils.combineFiles(Rscripts, scriptName);
        try {
            Runtime.getRuntime().exec("R --slave --no-save CMD BATCH " + scriptName);
        } catch (IOException io) {
            System.out.println(io.getMessage());
        }
    }*/
}