/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package flow;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author edroaldo
 */
public class FlowUtils {
    public static List<String> getSourcesSinks(String file) throws IOException{
        List<String> cellList = new ArrayList<String>();
        BufferedReader in = null;
        int cellColumn = 0;
        try{
            in  = new BufferedReader(new FileReader(file));
            in.readLine();
            String line;
            while((line = in.readLine()) != null){
                String[] columns = line.split("\\,");
                String gene = columns[cellColumn];
                cellList.add(gene);
            }
            return cellList;
        }
        finally {
        	in.close();
        }
    }
    
    public static void combineFiles(List<String> files, String combinedFile) {

        FileWriter fstream = null;
        BufferedWriter out = null;
        try {
            File mergedFile = new File(combinedFile);
            fstream = new FileWriter(mergedFile, true);
            out = new BufferedWriter(fstream);
        } catch (IOException e1) {
            e1.printStackTrace();
        }

        for (String file : files) {
            File f = new File(file);
            System.out.println("merging: " + f.getName());
            FileInputStream fis;
            try {
                fis = new FileInputStream(f);
                BufferedReader in = new BufferedReader(new InputStreamReader(fis));

                String aLine;
                while ((aLine = in.readLine()) != null) {
                    out.write(aLine);
                    out.newLine();
                }

                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try {
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    
    public static void getNumEdges(Map<String, Node> network){
        int numEdges = 0;
        for(String n:network.keySet()){
            Node p = network.get(n);
            numEdges += p.getEdges().size();
        }
        System.out.println("NUMBER OF EDGES" + numEdges);
    }
    
    public static void savePaths(List<Path> paths,
            String file) throws IOException {
    
        //List<Path> paths = new ArrayList();
        for(Path path:paths){
            //Path path = convertString2Path(auxPath);
            for(int i = path.getPath().size() - 1; i >= 0; i--){
                Edge auxE = path.getPath().get(i);
                if (i > 0) {
                    Edge nextEdge = path.getPath().get(i - 1);
                    if (!auxE.getTo().getName().equals(nextEdge.getFrom().getName())) {
                        Edge tmpEdge = new Edge(nextEdge.getTo(), nextEdge.getFrom());
                        tmpEdge.setFlow(nextEdge.getFlow());
                        //tmpEdge.setSignScore(nextEdge.getSignScore());
                        path.getPath().set(i - 1, tmpEdge);
                    }
                }
            }
        }
        
        try {
            File f = new File(file);
            if (!f.exists()) {
                f.createNewFile();
            }
            FileWriter fw = new FileWriter(f.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write("path\tpath_cost\tpath_flow\tsource\tsink\trank\tlength");
            bw.newLine();
            for (Path p : paths) {
                Path rPath = p.reversePath();
                double rank = p.flow / p.path.size();
                //bw.write(p.toString() + "\t" + p.cost + "\t" + p.flow);
                bw.write(rPath.toString() + "\t" + p.cost + "\t" + p.flow + "\t" + 
                        rPath.getPath().get(0).getTo() + "\t" +
                        rPath.getPath().get(rPath.getPath().size()-1).getFrom() + "\t" +
                        rank + "\t" + p.path.size());
                bw.newLine();
            }
            bw.close();
        } catch (IOException io) {
        	throw new IOException("Trouble creating or writing to " + file);
        }
    }
    
    public static void saveTotalFlow(Map<String, Node> network, 
                                String head,
                                String file) throws IOException{
            File f = new File(file);
            if(!f.exists()){
                f.createNewFile();
            }
            FileWriter fw = new FileWriter(f.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(head + "\t" + "netflow");
            bw.newLine();
            for (String n : network.keySet()) {
                Node n1 = network.get(n);
                //if(n1.getName().equals("s") || n1.getName().equals("t")) continue;
                bw.write(n1.getSymbol() + "\t" + n1.getTotalFlow());
                bw.newLine();
            }
            bw.close();
    }
    
    public static void saveTotalFlowByCategory(Map<String, Node> network,
                                        String comparison,
                                        List<Node> proteins,
                                        String head,
                                        String file) throws IOException{
            File f = new File(file);
            if(!f.exists()){
                f.createNewFile();
            }
            FileWriter fw = new FileWriter(f.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write("comparison" + "\t" + head + "\t" + "netflow");
            bw.newLine();
            for (Node n : proteins) {
                String aux = n.getSymbol().split("\\/")[0];
                //bw.write(comparison + "\t" + n.getSymbol() + "\t" + n.getTotalFlow());
                bw.write(comparison + "\t" + aux + "\t" + n.getTotalFlow());
                bw.newLine();
            }
            bw.close();
    
    }
    public static List<Node> getTopSources(Map<String, Node> subnet, int top){
        List<Node> proteins = new ArrayList();
        List<Edge> edges = subnet.get("s").getEdges();
        for(Edge e:edges){
            proteins.add(subnet.get(e.getTo().getName()));
        }
        Collections.sort(proteins, (Node n1, Node n2) -> Double.compare(n1.getTotalFlow(), n2.getTotalFlow()));
        List<Node> topProteins = proteins.subList(proteins.size() - top, proteins.size());
        return topProteins;
    }
    
    public static Map<String, Double> getSources(Map<String, Node> subnet, int top){
        List<Node> proteins = new ArrayList();
        List<Edge> edges = subnet.get("s").getEdges();
        for(Edge e:edges){
            proteins.add(subnet.get(e.getTo().getName()));
        }
        Collections.sort(proteins, (Node n1, Node n2) -> Double.compare(n1.getTotalFlow(), n2.getTotalFlow()));
        List<Node> auxProteins = null;
        if(proteins.size() < top + 1){
            auxProteins = proteins;
        }else{
            auxProteins = proteins.subList(proteins.size() - top, proteins.size());
        }
        Map<String, Double> topProteins = new LinkedHashMap();
        for(Node n:auxProteins){
            topProteins.put(n.getSymbol(), n.getTotalFlow());
        }
        return topProteins;
    }
    
    public static Map<String, Double> getTotalFlow(Map<String, Node> subnet){
        Map<String, Double> totalFlow = new LinkedHashMap();
        for(String n:subnet.keySet()){
            Node node = subnet.get(n);
            totalFlow.put(node.getSymbol(), node.getTotalFlow());
        }
        return totalFlow;
    }
    
    public static Map<String, Double> getSinks(Map<String, Node> subnet){
        List<Node> proteins = new ArrayList();
        List<Edge> edges = subnet.get("t").getEdges();
        for(Edge e:edges){
            proteins.add(subnet.get(e.getFrom().getName()));
        }
        Map<String, Double> totalFlow = new LinkedHashMap();
        for(Node n:proteins){
            totalFlow.put(n.getSymbol(), n.getTotalFlow());
        }
        return totalFlow;
    }

    public static Map<String, Double> getSources(Map<String, Node> subnet){
        List<Node> proteins = new ArrayList();
        List<Edge> edges = subnet.get("s").getEdges();
        for(Edge e:edges){
            proteins.add(subnet.get(e.getTo().getName()));
        }
        Map<String, Double> totalFlow = new LinkedHashMap();
        for(Node n:proteins){
            totalFlow.put(n.getSymbol(), n.getTotalFlow());
        }
        return totalFlow;
    }
    
    public static Map<String, Double> getHiddenProteins(Map<String, Node> subnet){
        List<String> proteins = new ArrayList(subnet.keySet());
        Set<String> sources = getSources(subnet).keySet();
        Set<String> sinks = getSinks(subnet).keySet();
        proteins.removeAll(sources);
        proteins.removeAll(sinks);
        proteins.remove("t");
        proteins.remove("s");
        Map<String, Double> totalFlow = new LinkedHashMap();
        for(String n:proteins){
            totalFlow.put(n, subnet.get(n).getTotalFlow());
        }
        return totalFlow;
    }
    
    public static Map<String, Double> getSinks(Map<String, Node> subnet, int top){
        List<Node> proteins = new ArrayList();
        List<Edge> edges = subnet.get("t").getEdges();
        for(Edge e:edges){
            proteins.add(subnet.get(e.getFrom().getName()));
        }
        Collections.sort(proteins, (Node n1, Node n2) -> Double.compare(n1.getTotalFlow(), n2.getTotalFlow()));
        List<Node> auxProteins = null;
        if(proteins.size() < top + 1){
            auxProteins = proteins;
        }else{
            auxProteins = proteins.subList(proteins.size() - top, proteins.size());
        }
        Map<String, Double> topProteins = new LinkedHashMap();
        for(Node n:auxProteins){
            topProteins.put(n.getSymbol(), n.getTotalFlow());
        }
        return topProteins;
    }
    
    public static List<Node> getTopSinks(Map<String, Node> subnet, int top){
        List<Node> proteins = new ArrayList();
        List<Edge> edges = subnet.get("t").getEdges();
        for(Edge e:edges){
            proteins.add(subnet.get(e.getFrom().getName()));
        }
        Collections.sort(proteins, (Node n1, Node n2) -> Double.compare(n1.getTotalFlow(), n2.getTotalFlow()));
        List<Node> topProteins = proteins.subList(proteins.size() - top, proteins.size());
        return topProteins;
    }
    
    public static List<String> transformPaths2String(List<Path> paths){
        List<String> auxPaths = new ArrayList();
        for(Path p:paths){
            auxPaths.add(convertPath2String(p.getPath(), true));
        }
        return auxPaths;
    }
    
    public static List<Path> transform2Paths(List<List<Edge>> paths){
        List<Path> newPaths = new ArrayList();
        for(List<Edge> path:paths){
            Path p = new Path(path);
            newPaths.add(p);
        }
        return newPaths;
    }
    
    public static int intersection(List<String> list1, List<String> list2){
        List<String> intersection = new ArrayList<String>();
        
        for(String s:list1){
            if(list2.contains(s)){
                intersection.add(s);
            }
        }
        return intersection.size();
    }
    
    
    public static List<Path> convertString2Paths(List<String> pathsDisease) {
        
        List<Path> auxPaths = new ArrayList();
        for (String path : pathsDisease) {
            auxPaths.add(convertString2Path(path));
        }

        return auxPaths;
    }
    
    public static Map<Node, Map<Node, Integer>> createAdjacencyMatrix(Map<String, Node> network){
        Map<Node, Map<Node, Integer>> adj = new LinkedHashMap();
        for(String p1:network.keySet()){
            Node protein = network.get(p1);
            List<Node> neigh = getNeighbors(protein);
            Map<Node, Integer> aux = new LinkedHashMap();
            for(String p2:network.keySet()){
                Node protein2 = network.get(p2);
                if(neigh.contains(protein2)){
                    aux.put(protein2, 1);
                }else{
                    aux.put(protein2, 0);
                }
            }
            adj.put(protein, aux);
        }
        return adj;
    }
    
    public static List<Node> getNeighbors(Node protein){
        List<Node> neigh = new ArrayList();
        for(Edge e:protein.getEdges()){
            neigh.add(e.getOther(protein));
        }
        return neigh;
    }
    
    /*public static List<String> getPathsFromGenes(
            Map<String, Node> network,
            List<String> networkPaths,
            List<String> genes, 
            RJava rJava,
            String dir,
            String filename) throws IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException{
        
        List<String> scripts = new ArrayList();
        for (String d : genes) {
            List<String> stringPath = new ArrayList();
            if (network.containsKey(d)) {
                Set<Edge> edges = new LinkedHashSet(network.get(d).getEdges());
                Map<Edge, List<Path>> edge2path = getPathsFromEdges(networkPaths, edges);
                for (Edge e : edge2path.keySet()) {
                    for (Path p : edge2path.get(e)) {
                        stringPath.add(convertPath2String(p.getPath(), true));
                    }
                }
            }
            if(stringPath.isEmpty()) continue;
            Map<String, Node> subnet = createNetworkFromPaths(stringPath);
            //(new NetworkFlow()).printNetwork(subnet);
            //System.out.println(filename + "_" + d + ".txt");
            saveAdjMatrix(createAdjacencyMatrix(subnet), filename + "_" + d + ".txt");
            
            //rJava.plotAdjMatrix("", filename + "_" + d, d);
            scripts.add(rJava.createAdjAdjMatrixScript("", filename + "_" + d, d));
            
       }
        return scripts;
    }*/
    
    public static void getJaccardIndex(
            Map<String, Node> network,
            List<Node> nodes,
            String filename){
        
        Set<String> proteins = new LinkedHashSet();
        for(Node n:nodes){
            proteins.add(n.getName());
        }
        System.out.println("proteins: " + proteins.size());
        proteins.retainAll(network.keySet());
        proteins.retainAll(network.keySet());
        System.out.println("proteins: " + proteins.size());
        
        NetworkFlow net = new NetworkFlow();
        Map<String, Map<String, Double>> similarityMatrix = new LinkedHashMap();
        
        for (String c : proteins) {
            Node diseaseProtein = network.get(c);
            ArrayList<String> neigh = new ArrayList(diseaseProtein.getNeighborsBasedOnFlow(0.0));
            
            for (String e : proteins) {
                Node controlProtein = network.get(e);
                //if(controlProtein == null) continue;
                ArrayList<String> neigh2 = new ArrayList(controlProtein.getNeighborsBasedOnFlow(0.0));
                ArrayList<String> inter = net.intersect(neigh, neigh2);
                Set<String> union = net.union(neigh, neigh2);
                //System.out.println("------------------------------------");
                //System.out.println(inter.size() + " / " + union.size());
                double jaccard = 0.0;
                if (inter.isEmpty() && union.isEmpty()) {
                    jaccard = 1.0;
                } else {
                    jaccard = Double.valueOf(inter.size()) / Double.valueOf(union.size());
                }
                System.out.println(diseaseProtein.getSymbol() + "\t" + controlProtein.getSymbol() + "\t" + jaccard);
                //System.out.println("-----------------------------------");
                
                if(!similarityMatrix.containsKey(diseaseProtein.getSymbol())){
                    Map<String, Double> auxSimilarityMatrix = new LinkedHashMap();
                    auxSimilarityMatrix.put(controlProtein.getSymbol(), jaccard);
                    similarityMatrix.put(diseaseProtein.getSymbol(), auxSimilarityMatrix);
                }else{
                    similarityMatrix.get(diseaseProtein.getSymbol()).put(controlProtein.getSymbol(), jaccard);
                }
            }
            //similarityMatrix.put(diseaseProtein.getSymbol(), auxSimilarityMatrix);
           
        }
        saveJaccard(similarityMatrix, filename);
    }
    
    public static Path convertString2Path(String auxPath){
        String[] auxEdges = auxPath.split("\\,");
        List<Edge> edges = new ArrayList();
        for(int i = 0; i < auxEdges.length; i++){
            Node from = new Node(auxEdges[i].split("\\->")[0]);
            Node to = new Node(auxEdges[i].split("\\->")[1]);
            from.setSymbol(from.getName());
            to.setSymbol(to.getName());
            Double flow = Double.valueOf(auxEdges[i].split("\\->")[2]);
            Double signScore = Double.valueOf(auxEdges[i].split("\\->")[3]);
            Double cost = Double.valueOf(auxEdges[i].split("\\->")[4]);
            
            Edge e = new Edge(from, to);
            e.setFlow(flow);
            e.setSignScore(signScore);
            e.setCost(cost);
            //System.out.println(e.getFlow() + "\t" + e.getSignScore());
            edges.add(e);
        }
        //System.out.println(edges);
        return new Path(edges);
    }
    
    public static Map<Node, Map<Node, Double>> createMatrix(Map<String, Node> network){
        Map<Node, Map<Node, Double>> adj = new LinkedHashMap();
        for(String p1 : network.keySet()) {
            Node protein1 = network.get(p1);
            Map<Node, Double> aux = new LinkedHashMap();
            List<Node> neigh = FlowUtils.getNeighbors(protein1);
            
            for (String p2 : network.keySet()) {
                Node protein2 = network.get(p2);
                if (neigh.contains(protein2)) {
                    Edge e1 = new Edge(protein1, protein2);
                    Edge e2 = new Edge(protein2, protein1);
                    Edge rE1 = FlowUtils.getEdge(network, e1);
                    Edge rE2 = FlowUtils.getEdge(network, e2);
                    if (rE1 != null) {
                        aux.put(protein2, rE1.getFlow());
                    }else{
                        aux.put(protein2, rE2.getFlow());
                    }
                } else {
                    aux.put(protein2, 0.0);
                }
            }
            adj.put(protein1, aux);
        }   
        
        return adj;
    }
    
    public static void saveMatrix(
            Map<Node, Map<Node, Double>> flowMatrix,
            String file) throws IOException {

        File f = new File(file);
        if (!f.exists()) {
            f.createNewFile();
        }
        FileWriter fw = new FileWriter(f.getAbsoluteFile());
        BufferedWriter bw = new BufferedWriter(fw);

        int i = 0;
        for (Node gene : flowMatrix.keySet()) {
            Map<Node, Double> netflow = flowMatrix.get(gene);
            if (i == 0) {
                for (Node protein : netflow.keySet()) {
                    String auxSymbol = protein.getSymbol().split("\\/")[0];
                    String symbol = auxSymbol.replace("-", "_");
                    bw.write("\t" + symbol);
                    //bw.write(protein.getSymbol() + "\t");
                }
                bw.newLine();
                i = 1;
            }
            //bw.write(gene.getSymbol() + "\t");
            String auxSymbol = gene.getSymbol().split("\\/")[0];
            String symbol = auxSymbol.replace("-", "_");
            bw.write(symbol);
            for (Node protein : netflow.keySet()) {
                bw.write("\t" + netflow.get(protein));
            }
            bw.newLine();
        }
        bw.close();
    }
    
    
    public static Map<String, Double> getTotalFlowInProteins(
            Map<String, Double> totalFlows,
            Set<String> genes){
        
        Map<String, Double> total = new LinkedHashMap();
        for(String gene:genes){
            total.put(gene, totalFlows.get(gene));
        }
        return total;
    }
    
    public static List<String> convertPaths2String(List<Path> paths){
        List<String> newPaths = new ArrayList();
        for(Path p:paths){
            newPaths.add(convertPath2String(p.getPath(), true));
        }
        return newPaths;
    }
    
    
    public Map<String, Map<String, Double>> changeMapping(
            Map<String, Map<String, Double>> edgesMatrix){
        
        //invert the mappings from array->edge->flow to edge->array->flow
        Map<String, Map<String, Double>> auxEdgesMatrix = new LinkedHashMap();
        for (String array : edgesMatrix.keySet()) {
            for (String edge : edgesMatrix.get(array).keySet()) {
                if (!auxEdgesMatrix.containsKey(edge)) {
                    Map<String, Double> aux2 = new LinkedHashMap();
                    aux2.put(array, edgesMatrix.get(array).get(edge));
                    auxEdgesMatrix.put(edge, aux2);
                } else {
                    auxEdgesMatrix.get(edge).put(array, edgesMatrix.get(array).get(edge));
                }
            }
        }
        return auxEdgesMatrix;
    }
    
    public static Map<String, Node> createMotifImpactScore(List<Edge> edges){
        Map<String, Node> subnet = new LinkedHashMap();
        NetworkFlow net = new NetworkFlow();
        
        for (Edge e : edges) {
            Node from = new Node(e.getFrom().getName());
            Node to = new Node(e.getTo().getName());
            if(from.getName().equals("s") || to.getName().equals("t")) continue;

            from.setSymbol(from.getName());
            to.setSymbol(to.getName());
            
            Edge edge = new Edge(from, to);
            edge.setFlow(e.getFlow());
            edge.setSignScore(e.getSignScore());
            
            if(!net.hasNode(subnet, from)) net.addNode(subnet, from);
            if(!net.hasNode(subnet, to)) net.addNode(subnet, to);
                
            if (!subnet.get(from.getName()).getEdges().contains(e)) {
                subnet.get(from.getName()).addEdge(e);
            }
            if (!subnet.get(to.getName()).getEdges().contains(e)) {
                subnet.get(to.getName()).addEdge(e);
            }
        }
        return subnet;
    }
    
    public static void saveSubNet(Map<String, Node> subnet, String file) {
        ArrayList<Edge> edges = new ArrayList<Edge>();
        try {
            PrintWriter pw = new PrintWriter(new FileOutputStream(file));
            //pw.println("\nfrom\tto\tflow\tpath\ttype");
            //pw.println("\nfrom\tto\tedge_flow");
            pw.println("\nfrom\tto\tedge_flow\tcorrelation\tsign");
            for (String s : subnet.keySet()) {
                Node n = subnet.get(s);
                for (Edge e : n.getEdges()) {
                    //System.out.println("sign: " + e + "\t" +  e.getFlow() + "\t" + e.getSignScore() + "\t" + );
                    Integer sign = 0;
                    if(e.getSignScore() > 0){
                        sign = 1;
                    }else{
                        sign=-1;
                    }
                    if (!edges.contains(e)) {
                        pw.println(e.getFrom().getSymbol() + "\t"
                                + e.getTo().getSymbol() + "\t" + e.getFlow() + "\t" + 
                                e.getSignScore() + "\t" + sign);

                        edges.add(e);
                    }
                }
            }
            pw.close();
        } catch (IOException io) {
            System.out.println(io.getMessage());
        }
        System.out.println("Subnet size: " + subnet.size());
    }
    
    public static Map<String, Node> createNetworkFromPaths(List<String> paths){
        
        Map<String, Node> subnet = new LinkedHashMap();
        NetworkFlow net = new NetworkFlow();
        
        for(String auxPath:paths){
            Path path = convertString2Path(auxPath);
            for(int i = 0; i < path.getPath().size(); i++){
                Edge auxE = path.getPath().get(i);
                //if(auxE.getFrom().getName().equals("s")) continue;
                //if(auxE.getTo().getName().equals("t")) continue;
                Node from = new Node(auxE.getFrom().getName());
                from.setSymbol(auxE.getFrom().getSymbol());
                Node to = new Node(auxE.getTo().getName());
                to.setSymbol(auxE.getTo().getSymbol());
                
                if(!net.hasNode(subnet, from)) net.addNode(subnet, from);
                if(!net.hasNode(subnet, to)) net.addNode(subnet, to);
                
                Edge e = new Edge(from, to);
                e.setFlow(auxE.getFlow());
                e.setSignScore(auxE.getSignScore());
                
                
                if(!subnet.get(from.getName()).getEdges().contains(e)){
                    subnet.get(from.getName()).addEdge(e);
                }
                if(!subnet.get(to.getName()).getEdges().contains(e)){
                    subnet.get(to.getName()).addEdge(e);
                }
            }
        }
        //System.out.println("------------subnet from paths----------");
        //System.out.println(subnet.size());
        //printNetwork(subnet);
        return subnet;
    }
    
    public static Map<String, Node> createNetworkFromPaths2Plot(List<String> paths){
        
        Map<String, Node> subnet = new LinkedHashMap();
        NetworkFlow net = new NetworkFlow();
        
        for(String auxPath:paths){
            Path path = convertString2Path(auxPath);
            for(int i = path.getPath().size() - 1; i >= 0; i--){
                Edge auxE = path.getPath().get(i);
                if (i > 0) {
                    Edge nextEdge = path.getPath().get(i - 1);
                    if (!auxE.getTo().getName().equals(nextEdge.getFrom().getName())) {
                        Edge tmpEdge = new Edge(nextEdge.getTo(), nextEdge.getFrom());
                        tmpEdge.setFlow(nextEdge.getFlow());
                        tmpEdge.setSignScore(nextEdge.getSignScore());
                        path.getPath().set(i - 1, tmpEdge);
                    }
                }
                //if(auxE.getFrom().getName().equals("s")) continue;
                //if(auxE.getTo().getName().equals("t")) continue;
                Node from = new Node(auxE.getFrom().getName());
                from.setSymbol(auxE.getFrom().getSymbol());
                Node to = new Node(auxE.getTo().getName());
                to.setSymbol(auxE.getTo().getSymbol());
                
                if(!net.hasNode(subnet, from)) net.addNode(subnet, from);
                if(!net.hasNode(subnet, to)) net.addNode(subnet, to);
                
                Edge e = new Edge(from, to);
                e.setFlow(auxE.getFlow());
                e.setSignScore(auxE.getSignScore());
                
                if(!subnet.get(from.getName()).getEdges().contains(e)){
                    subnet.get(from.getName()).addEdge(e);
                }
                if(!subnet.get(to.getName()).getEdges().contains(e)){
                    subnet.get(to.getName()).addEdge(e);
                }
            }
        }
        //System.out.println("------------subnet from paths----------");
        //System.out.println(subnet.size());
        //printNetwork(subnet);
        return subnet;
    }

    public static List<Double> splitEdgesFlow(String path){
        String[] edges = path.split("\\,");
        List<Double> flows = new ArrayList();
        for(int i = 0; i < edges.length; i++){
            Double flow = Double.valueOf(edges[i].split("\\->")[2]);
            flows.add(flow);
        }
        return flows;
    }
    public static List<Double> splitEdgesCost(String path){
        String[] edges = path.split("\\,");
        List<Double> flows = new ArrayList();
        for(int i = 0; i < edges.length; i++){
            Double flow = Double.valueOf(edges[i].split("\\->")[3]);
            flows.add(flow);
        }
        return flows;
    }
    
    
    public static String convertPath2String(List<Edge> path, boolean flow){
        String s = "";
        for(int i = 0; i < path.size(); i++){
        //for(Edge e:path){
            Edge e = path.get(i);
            //String[] s1 =  e.getFrom().getName().split("\\/");
            //String[] s2 =  e.getTo().getName().split("\\/");
            String s1 =  e.getFrom().getName();
            String s2 =  e.getTo().getName();
            
            if(flow){
                if(i == path.size() - 1){
                    s += s1 + "->" + s2 + "->" + e.getFlow() + "->" + e.getSignScore() + "->" + e.getCost();
                }else{
                    s += s1 + "->" + s2 + "->" + e.getFlow() + "->" + e.getSignScore() + "->" + e.getCost() + ",";
                }
            }else{
                if(i == path.size() - 1){
                    s += s1 + "->" + s2;
                }else{
                    s += s1 + "->" + s2 + ",";
                }
            }
        }
        return s;
    }
    
    //--------------------------------------------------------------------------
    
    public static Edge getEdge(Map<String, Node> network, Edge e) {
        if (network.get(e.getFrom().getName()) == null) {
            return null;
        } else {
            for (Edge es : network.get(e.getFrom().getName()).getEdges()) {
                if (es.getFrom().getName().equals(e.getFrom().getName())
                        && es.getTo().getName().equals(e.getTo().getName())) {
                    return es;
                }
            }
        }
        return null;
    }
    
    public static void saveAdjMatrix(
            Map<Node, Map<Node, Integer>> adjMatrix,
            String file) throws IOException{
        
            File f = new File(file);
            if(!f.exists()){
                f.createNewFile();
            }
            FileWriter fw = new FileWriter(f.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            
            int i = 0;
            bw.write("gene");
            for (Node gene : adjMatrix.keySet()) {
                Map<Node, Integer> netflow = adjMatrix.get(gene);
                if(i == 0){
                    for(Node protein:netflow.keySet()){
                        String auxSymbol = protein.getSymbol().split("\\/")[0];
                        String symbol = auxSymbol.replace("-", "_");
                        bw.write("\t" + symbol);
                        //bw.write(protein.getSymbol() + "\t");
                    }
                    bw.newLine();
                    i = 1;
                }
                //bw.write(gene.getSymbol() + "\t");
                String auxSymbol = gene.getSymbol().split("\\/")[0];
                String symbol = auxSymbol.replace("-", "_");
                bw.write(symbol);
                for (Node protein : netflow.keySet()) {
                    bw.write("\t" + netflow.get(protein));
                }
                bw.newLine();
            }
            bw.close();
    }
    
    
    public static void saveFlows(
            Map<String, Double> differences,
            String file) throws IOException {
        
        try{
            File f = new File(file);
            if(!f.exists()){
                f.createNewFile();
            }
            FileWriter fw = new FileWriter(f.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write("cell\tflows");
            bw.newLine();
            for (String gene : differences.keySet()) {
                bw.write(gene + "\t" + differences.get(gene));
                bw.newLine();
            }
            bw.close();
        }catch(IOException e){
			throw new IOException("Error creating or writing " + file, e);
        }
    }
    
    public static void saveGeneList(
            Map<String, Node> network,
            String file) throws IOException {

        try {
			File f = new File(file);
			if (!f.exists()) {
			    f.createNewFile();
			}
			FileWriter fw = new FileWriter(f.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write("gene");
			bw.newLine();
			for (String gene : network.keySet()) {
			    String symbols = network.get(gene).getSymbol();
			    String symbol = symbols.split("\\/")[0];
			    bw.write(symbol);
			    //bw.write(network.get(gene).getSymbol());
			    bw.newLine();
			}
			bw.close();
		} catch (IOException e) {
			throw new IOException("Error creating or writing " + file, e);
		}
    }

    
public static void saveJaccard(
            Map<String, Map<String, Double>> similarityMatrix,
            String file) {
        //Map<String, OntologyUtils.Term> utils = new OntologyUtils().getGOHierarchy();
        try {
            File f = new File(file);
            if (!f.exists()) {
                f.createNewFile();
            }
            FileWriter fw = new FileWriter(f.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            //for(String s:mapping.keySet()){
            //    bw.write("\t" + s);
            //}
            bw.newLine();
            boolean column = false;
            for (String c : similarityMatrix.keySet()) {
                if (!column) {
                    for (String g : similarityMatrix.get(c).keySet()) {
                        bw.write("\t" + g);
                    }
                    column = true;
                    bw.newLine();
                }

                bw.write(c);
                for (String g : similarityMatrix.get(c).keySet()) {
                    //System.out.println(c + "\t" + g + "\t" + mapping.get(c).get(g));
                    bw.write("\t" + similarityMatrix.get(c).get(g));
                }
                bw.newLine();

            }
            bw.close();
        } catch (IOException io) {
        }
    }
}