/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package flow;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author edroaldo
 */
public class InputOutput {
    private List<String> from;
    private List<String> to;
    private List<Double> weights;
    private String file;
    private final int FROM = 0;
    private final int TO = 1;
    private final int WEIGHT = 2;
    private final int SIGNCOR = 3;
    private List<Double> signCors;
    
    public InputOutput(){
        from = new ArrayList();
        to = new ArrayList();
        weights = new ArrayList();
        signCors = new ArrayList();
    }
    public InputOutput(String file){
        super();
        this.file = file;
    }

    public void getNetworkData(String file) throws IOException{
        BufferedReader in = null;
        try{
            in = new BufferedReader(new FileReader(file));
            String line;
            while((line = in.readLine()) != null){
                String columns[] = line.split("\t");
                //System.out.println(columns[0] + " " + columns[1] + " " + columns[2]);
                getFrom().add(columns[FROM]);
                getTo().add(columns[TO]);
                getWeights().add(Double.valueOf(columns[WEIGHT]));
                getSignCors().add(Double.valueOf(columns[SIGNCOR]));
            }
        }
        finally {
            in.close();
        }
    }

    /**
     * @return the from
     */
    public List<String> getFrom() {
        return from;
    }

    /**
     * @param from the from to set
     */
    public void setFrom(List<String> from) {
        this.from = from;
    }

    /**
     * @return the to
     */
    public List<String> getTo() {
        return to;
    }

    /**
     * @param to the to to set
     */
    public void setTo(List<String> to) {
        this.to = to;
    }

    /**
     * @return the weights
     */
    public List<Double> getWeights() {
        return weights;
    }

    /**
     * @param weights the weights to set
     */
    public void setWeights(List<Double> weights) {
        this.weights = weights;
    }

    /**
     * @return the signCors
     */
    public List<Double> getSignCors() {
        return signCors;
    }

    /**
     * @param signCors the signCors to set
     */
    public void setSignCors(List<Double> signCors) {
        this.signCors = signCors;
    }
}