
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cellrouter;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.PriorityQueue;
import java.util.Set;

/**
 *
 * @author edroaldo
 */
public class NetworkFlow implements Serializable{
    //private Map<String, List<String>> network;
    //private Map<String, Node> network;
    private Map<String, Integer> symbolTable;
    private Map<String, NodeInfo> nodesPath = new LinkedHashMap<String, NodeInfo>();
    private Map<String, Edge> edgeTo;
    private Map<String, Double> distTo;
    private IndexMinPQ<Double> ipq;
    private Node source;
    private Node target;
    private double value;
    private int E;
    private PriorityQueue<Edge> pq;
    private Queue<Edge> mst;
    private double cost;
    private String keys[];
    
    Set<String> enrichment = new LinkedHashSet<String>();   //Proteinas para GO analysis
    LinkedHashSet<Edge> predicted = new LinkedHashSet<Edge>();  //interacoes preditas
    int pathNum = 1;
    Map<Integer, List<Edge>> highScoreProteins = new LinkedHashMap<Integer, List<Edge>>();
    //LinkedHashMap<String, Node> subnet = new LinkedHashMap<String, Node>();
        
    public NetworkFlow(){ 
        //network = new LinkedHashMap<String, List<String>>();
        //network = new LinkedHashMap<String, Node>();
        pq = new PriorityQueue<Edge>();
        value = 0.0;
        E = 0;
    }
    
    public NetworkFlow(Node source, Node target){
        this.source = source;
        this.target = target;
    }
    
    public void createNetwork(
            List<Node> sources,
            List<Node> sinks,
            Map<String, Node> network,
            List<String> froms, 
            List<String> tos,
            List<Double> weight){
        
        Node s = new Node("s");
        Node t = new Node("t");
        s.setSymbol("s");
        t.setSymbol("t");
        
        for(int i = 0; i < froms.size(); i++){
            Node from = new Node(froms.get(i));
            Node to = new Node(tos.get(i));
            from.setSymbol(from.getName());
            to.setSymbol(to.getName());
            
            Edge edge = new Edge(from, to);
            edge.setCapacity(weight.get(i));
            edge.setCost(-Math.log(weight.get(i)));
            edge.setFlow(0.0);
            addEdge(network, edge);
            //System.out.println(edge.getMiscore() + "\t" + edge.getSignScore());
        }
        
        System.out.println("Number of sources: " + sources.size());
        System.out.println("Number of sinks: " + sinks.size());
        System.out.println("Network size before: " + network.size());
        this.addSourceAndTarget(network, s, t, sources, sinks);
    }

    public Map<Integer, List<Edge>> buildSubnet(Map<String, Node> network, 
            Map<String, Node> subnet,
            Map<Integer, Map<String, Edge>> allPaths){
        //Create a subnetwork connecting sources and targets through interactome edges
        //Aqui, network se refere a rede total, nao a subrede
        Map<Integer, Map<String, Edge>> auxPath = new LinkedHashMap<Integer, Map<String, Edge>>();
        int pathNum = 0;
        
        System.out.println("path size before: " + allPaths.size());
        for(int i = 0; i < allPaths.size(); i++){
            Map<String, Edge> path = allPaths.get(i);
            boolean flag = false;
            //System.out.println(i);
            for (String v = target.getName(); !v.equals(source.getName());
                    v = path.get(v).getOther(network.get(v)).getName()) {
                
                if(path.get(v).getFlow() == 0.0){
                    flag = true;
                    break;
                }
            }
            if(!flag){
                auxPath.put(pathNum, path);
                pathNum++;
            }
        }
        System.out.println("path size after: " + auxPath.size());
        for (int i = 0; i < auxPath.size(); i++) {
            Map<String, Edge> path = auxPath.get(i);
            for (String v = target.getName(); !v.equals(source.getName());
                    v = path.get(v).getOther(network.get(v)).getName()) {
              
                Node from = new Node(path.get(v).getFrom().getName());
                Node to = new Node(v);
                
                from.setSymbol(network.get(from.getName()).getSymbol());
                to.setSymbol(network.get(to.getName()).getSymbol());
                
                if (!hasNode(subnet, from)) {
                    addNode(subnet, from);
                }
                if (!hasNode(subnet, to)) {
                    addNode(subnet, to);
                }

                Edge e = new Edge(from, to);
                e.setCapacity(path.get(v).getCapacity());
                e.setMiscore(path.get(v).getMiscore());
                e.setFlow(path.get(v).getFlow());
                e.setCost(path.get(v).getCost());
                e.setSignScore(path.get(v).getSignScore());
                
                if (!subnet.get(from.getName()).getEdges().contains(e)) {
                    subnet.get(from.getName()).addEdge(e);
                }
                if (!subnet.get(to.getName()).getEdges().contains(e)) {
                    subnet.get(to.getName()).addEdge(e);
                }
            }
        }
        Map<Integer, List<Edge>> pathsSubnet = getPaths(auxPath, subnet);
        return pathsSubnet;
        //return auxPath;
    }
    
    public static void main(String args[]) throws IOException{
        
    }
    
    /*
     * Java method to sort Map in Java by value e.g. HashMap or Hashtable
     * throw NullPointerException if Map contains null values
     * It also sort values even if they are duplicates
     */
    public static <K extends Comparable,V extends Comparable> Map<K,V> sortByValues(Map<K,V> map){
        List<Map.Entry<K,V>> entries = new LinkedList<Map.Entry<K,V>>(map.entrySet());
     
        Collections.sort(entries, new Comparator<Map.Entry<K,V>>() {

            @Override
            public int compare(Entry<K, V> o1, Entry<K, V> o2) {
                return o1.getValue().compareTo(o2.getValue());
            }
        });
     
        //LinkedHashMap will keep the keys in the order they are inserted
        //which is currently sorted on natural ordering
        Map<K,V> sortedMap = new LinkedHashMap<K,V>();
     
        for(Map.Entry<K,V> entry: entries){
            sortedMap.put(entry.getKey(), entry.getValue());
        }
     
        return sortedMap;
    }

    public void mappingNameToId(Map<String, Node> network){
        int i = 0;
        symbolTable = new LinkedHashMap();
        for(String p:network.keySet()){
            symbolTable.put(p, i++);
        }
        keys = new String[symbolTable.size()];
        for(String s:symbolTable.keySet()){
            keys[symbolTable.get(s)] = s;
        }
    }
    
    
    public int E(){
        return E;
    }

    
    public void printNetwork(Map<String, Node> network){
        String s = "";
        for(String p:network.keySet()){
            //System.out.println("------------------: " + p);
            s += network.get(p).getSymbol() + ": ";
            for(Edge e:network.get(p).getEdges()){
                //s += e.getFrom().getName() + "-" +e.getTo().getName() + " ";
                s += e.getFrom().getSymbol() + "-" +e.getTo().getSymbol() + " ";// + e.getCost() + " ";
            }
            s += "\n"; 
        }
        System.out.println(s);
    }
    
    public boolean hasNode(Map<String, Node> network, Node node){
        return network.containsKey(node.getName());
    }
    public boolean hasEdge(Map<String, Node> network, Edge edge){
        if(!hasNode(network, edge.getFrom())) return false;
        return network.get(edge.getFrom().getName()).getEdges().contains(edge);
    }
    
    public void addNode(Map<String, Node> network, Node node){
        if(!hasNode(network, node)){
            //network.put(node.getName(), new Node(node.getName()));
            network.put(node.getName(), node);
        }
    }
    
    public void addEdge(Map<String, Node> network, Edge edge){
        if(!hasEdge(network, edge)) E++;
        if(!hasNode(network, edge.getFrom())) addNode(network, edge.getFrom());
        if(!hasNode(network, edge.getTo())) addNode(network, edge.getTo());
        
        Edge edger = new Edge(edge.getTo(), edge.getFrom(), edge.getCapacity(), edge.getCost());
        
        network.get(edge.getFrom().getName()).addEdge(edge);
        network.get(edge.getFrom().getName()).addEdge(edger);
        network.get(edge.getTo().getName()).addEdge(edge);
        network.get(edge.getTo().getName()).addEdge(edger);
    }
    
    public Edge getEdge(Map<String, Node> network, Edge e){
        ArrayList<Edge> edges = network.get(e.getFrom().getName()).getEdges();
        System.out.println(edges);
         for(Edge es:network.get(e.getFrom().getName()).getEdges()){
            if(es.getFrom().getName().equals(e.getFrom().getName()) &&
                    es.getTo().getName().equals(e.getTo().getName())){
                return es;
            }
         }
        return null;
    }
    
    public boolean compute(Map<String, Node> network, 
            Map<Integer, Map<String, Edge>> allPaths) throws IOException{
        
        System.out.println("Computing flow");
        boolean augmented = false;
        if(!isFeasible(network, source, target)){
            System.out.println("Ferrou desde o inicio");
        }
        int i = 0;
        while(prim2(network, getNodesPath())){
            processPath(network, getNodesPath(), i, allPaths);
            check(network, source, target);
            augmented = true;
            i++;
            if(allPaths.size() % 10 == 0){
                System.out.println("Number of paths: " + allPaths.size());
            }
            //if(allPaths.size() == 50) break;
        }   
        return augmented;
    }
    
    public void processPath(Map<String, Node> network, Map<String, NodeInfo> nodesPath, int path,
            Map<Integer, Map<String, Edge>> allPaths){
        double delta = Double.MAX_VALUE;

        for (String v = target.getName(); !v.equals(source.getName()); v = edgeTo.get(v).getOther(network.get(v)).getName()) {
            network.get(v).getOutflowGOs().addAll(network.get(v).getCurrentGOs()); //LINHA IMPORTANTE GO SCORE ORIGINAL
            delta = Math.min(delta, edgeTo.get(v).residualCapacityTo(network.get(v)));
        }
        //augment flow
        for (String v = target.getName(); !v.equals(source.getName()); v = edgeTo.get(v).getOther(network.get(v)).getName()) {
            edgeTo.get(v).addResidualFlowTo(network.get(v), delta);
        }
        //---Armazena todos os paths para depois contruir a subrede
        allPaths.put(path, new LinkedHashMap<String, Edge>(edgeTo));
        value += delta;
        //Codigo auxiliar para mostrar os caminhos escolhidos/encontrados.
        for (String v = target.getName(); !v.equals(source.getName()); v = edgeTo.get(v).getOther(network.get(v)).getName()) {
            if (edgeTo.get(v).getFlow() > 0) {
                if (!v.equals(source.getName()) || !v.equals(target.getName())) {
                    cost += edgeTo.get(v).getCost();
                }
            }
        }
        nodesPath.clear();
    }

    public boolean prim2(Map<String, Node> network, Map<String, NodeInfo> nodes) {
        resetNodesVisited(network);
        ipq = new IndexMinPQ<Double>(network.size());
        Map<String, Boolean> inqueue = new LinkedHashMap();
        distTo = new LinkedHashMap();
        edgeTo = new LinkedHashMap();
        
        for (String n : network.keySet()) {
            inqueue.put(n, false);
        }
        for (String n : network.keySet()) {
            if (n.equals(source.getName())) {
                distTo.put(source.getName(), 0.0);
                ipq.insert(symbolTable.get(source.getName()), distTo.get(source.getName()));
                inqueue.put(source.getName(), true);
            } else {
                distTo.put(n, Double.MAX_VALUE);

            }
        }
        while (!ipq.isEmpty()) {
            Node u = network.get(keys[ipq.delMin()]);
            inqueue.put(u.getName(), false);
            
            Iterator<Edge> it = u.edges();
            while (it.hasNext()) {
                Edge e = it.next();
                //Node v = e.getOther(u).getName()
                Node v = network.get(e.getOther(u).getName()); //obtem o Node que eh adjacente a u
                
                if (v.getName().equals(this.source.getName()) || v.getName().equals(u.getName())) continue;
                if (e.residualCapacityTo(v) > 0) {
                    //if (e.getFlow() < e.getCapacity()) {
                    double newDist = distTo.get(u.getName()) + Math.abs(e.getCost());
                    if (0 <= newDist && newDist < distTo.get(v.getName())) {
                        nodes.put(v.getName(), new NodeInfo(u.getName(), true));
                        distTo.put(v.getName(), newDist);
                        edgeTo.put(v.getName(), e);
                        if (inqueue.get(v.getName())) {
                            ipq.decreaseKey(symbolTable.get(v.getName()), newDist);
                        } else {
                            ipq.insert(symbolTable.get(v.getName()), newDist);
                            inqueue.put(v.getName(), true);
                        }
                    }
                    if (v.getName().equals(target.getName())) {
                        return true;
                    }
                }
            }
        }

        return distTo.get(target.getName()) != Double.MAX_VALUE;
    }
    
    public Map<Integer, List<Edge>> getPaths(Map<Integer, Map<String, Edge>> paths, 
            Map<String, Node> network){
        
        Map<Integer, List<Edge>> allSinglePaths = new LinkedHashMap<Integer, List<Edge>>();
        for(int i = 0; i < paths.size(); i++){
            List<Edge> singlePath = new ArrayList<Edge>();
            Map<String, Edge> path = paths.get(i);
            for (String v = target.getName(); !v.equals(source.getName());
                    v = path.get(v).getOther(network.get(v)).getName()) {
                
                Edge e = path.get(v);
                singlePath.add(e);
                cost += e.getCost();
            }
            allSinglePaths.put(i, singlePath);
        }
        return allSinglePaths;
    }
    
    public Map<Integer, List<String>> showPaths(Map<Integer, Map<String, Edge>> paths, 
            Map<String, Node> network){
        
        Map<Integer, List<String>> allSinglePaths = new LinkedHashMap<Integer, List<String>>();
        for(int i = 0; i < paths.size(); i++){
            List<String> singlePath = new ArrayList<String>();
            Map<String, Edge> path = paths.get(i);
            for (String v = target.getName(); !v.equals(source.getName());
                    v = path.get(v).getOther(network.get(v)).getName()) {
                
                Edge e = path.get(v);
                if(e.getTo().getName().equals("t")){
                    singlePath.add(e.getTo().getName());
                }else if(e.getFrom().getName().equals("s")){
                    //System.out.print(e.getFrom().getSymbol());
                }
                //System.out.print(e.getFrom().getSymbol() + "->");
                
                singlePath.add(e.getFrom().getSymbol());
                cost += e.getCost();
            }
            allSinglePaths.put(i, singlePath);
            //sumCost += cost;
            //System.out.println("\nCost: " + cost);
        }
        //double meanCost = sumCost / paths.size();
        //System.out.println("Mean cost: " + meanCost);
        //System.out.println("Maxflow: " + value);
        
        return allSinglePaths;
    }
    
    
    public boolean shortestPaths(Map<String, Node> network, 
            Map<String, NodeInfo> nodes,
            Set<String> sinkGO){
        
        resetNodesVisited(network);
        //subEdgeTo = new LinkedHashMap<String, Edge>();
        edgeTo = new LinkedHashMap<String, Edge>();
        Queue<Node> queue = new Queue<Node>();
        source.setVisited(true);
        queue.enqueue(source);
        
        while(!queue.isEmpty()){
            Node u = network.get(queue.dequeue().getName());
            Iterator<Edge> it = u.edges();
            while(it.hasNext()){
                Edge e = it.next();
                Node v = network.get(e.getOther(u).getName());
                if (v.getName().equals(source.getName()) || v.getName().equals(u.getName())) continue;
                if(e.residualCapacityTo(v) > 0){
                    if (!v.isVisited()) {
                        if (u.getName().equals("s") || v.getName().equals("t")) {
                            edgeTo.put(v.getName(), e);
                            v.setVisited(true);
                            queue.enqueue(v);
                        }
                    }
                    if (v.getName().equals(target.getName())) {
                        return true;
                    }
                }
            }
        }
        
        return target.isVisited();
    }
    
    public ArrayList<String> intersect(ArrayList<String> list1, ArrayList<String> list2){
        ArrayList<String> intersection = new ArrayList();
        
        for(String s:list1){
            if(list2.contains(s)){
                intersection.add(s);
            }
        }
        
        return intersection;
    }
    public Set<String> union(ArrayList<String> list1, ArrayList<String> list2){
       Set<String> union = new LinkedHashSet();
       union.addAll(list1);
       union.addAll(list2);
       return union;
    }
    public void resetNodesVisited(Map<String, Node> network){
        //Set<Node> nodes = getNodes();
        for(String n:network.keySet()){
            network.get(n).setVisited(false);
        }
    }
    /*Proximo passo: extender para o um numero arbitrario de sources and sinks (targets)*/
    public void addSourceAndTarget(Map<String, Node> network, Node newSource, Node newTarget,List<Node> sources, List<Node> targets){
        //Basicamente, eu preciso atualizar a lista de adjancencia de cada Node in sources and targets
        //Verificar cuidadosamente como atribuir as capacidades entre (s0,si) e (ti,t0)
        //Node n1 = net.getNetwork().get("uniprotkb:P29366");
        List<Edge> edges = null;
        Node edgesSource = new Node(newSource.getName());
        Node edgesTarget = new Node(newTarget.getName());
        for(Node s:sources){
            edges = network.get(s.getName()).getEdges();
            double cap = 0.0;
            for (Edge e : edges) {
                cap += e.getCapacity();

            }
            Edge newEdge = new Edge(newSource, s, cap, 0);
            //System.out.println("Capacity Source; " + newEdge.getCapacity());
            edges.add(newEdge);
            edgesSource.addEdge(newEdge);    //source tem somente forward edges. (s0, si)
        }
        
        for(Node t:targets){
            //System.out.println("Target edges: ");
            if(network.get(t.getName()) == null){
                continue;
                
            }
            //System.out.println(network.get(t.getName()).getEdges());
            edges = network.get(t.getName()).getEdges();
            double cap = 0.0;
            for (Edge e : edges) {
                cap += e.getCapacity();
            }
            Edge newEdge = new Edge(t, newTarget, cap, 0);
            //System.out.println("Capacity Target; " + newEdge.getCapacity());
            edges.add(newEdge);
            edgesTarget.addEdge(newEdge);   //(ti,t0)
        }
        //Adicionar novos source e target a rede
        add(network, 0, newSource.getName(), edgesSource);
        network.put(newTarget.getName(), edgesTarget);
        network.get(newSource.getName()).setSymbol("s");
        network.get(newTarget.getName()).setSymbol("t");
        System.out.println("New source " + newSource.getSymbol() + " added");
        System.out.println("New target " + newTarget.getSymbol() + " added");
        this.setSource(newSource);
        this.setTarget(newTarget);
        System.out.println("Network size: " + network.size());
    }
    
    public void add(Map<String, Node> map, int index, String key, Node value){
        int i = 0;
        List<Entry<String, Node>> rest = new ArrayList<>();
        for(Entry<String, Node> entry:map.entrySet()){
            if(i++ >= index){
                rest.add(entry);
            }
        }
        map.put(key, value);
        for(int j = 0; j < rest.size(); j++){
            Entry<String,Node> entry = rest.get(j);
            map.remove(entry.getKey());
            map.put(entry.getKey(), entry.getValue());
        }
    }
    
    private boolean excess(Node v){
        double excess = 0.0;
        for(Edge e:v.getEdges()){
            if(v.getName().equals(e.getFrom().getName())){
                excess -= e.getFlow();
            }else{
                excess += e.getFlow();
            }
        }
        return Math.abs(excess) < 1E-11;
    }
    
    private boolean isFeasible(Map<String, Node> network, Node s, Node t){
        double EPSILON = 1E-11;
        
        //Check if the flow on edge is nonnegative and not greater than capacity
        for(String v:network.keySet()){
            for(Edge e:network.get(v).getEdges()){
                //if(e.getFlow() < 0 || e.getFlow() > e.getCapacity()){
                if(e.getFlow() < -EPSILON || e.getFlow() > e.getCapacity() + EPSILON){
                    System.out.println(e);
                    System.out.println("Capacity constraints are not satisfied");
                    return false;
                }
            }
        }
        for(String v:network.keySet()){
            if(!v.equals(source.getName()) && !v.equals(target.getName()) && !excess(network.get(v))){
                System.out.println("Flow equilibrium condition is not satisfied");
                return false;
            }
        }
        return true;
    }
    
    public boolean inCut(Node v){
        return v.isVisited();
    }
    
    public boolean check(Map<String, Node> network, Node s, Node t){
        if(!isFeasible(network, s, t)){
            System.out.println("Flow is not feasible");
            return false;
        }
        return true;
    }

    /**
     * @return the source
     */
    public Node getSource() {
        return source;
    }

    /**
     * @param source the source to set
     */
    public void setSource(Node source) {
        this.source = source;
    }

    /**
     * @return the target
     */
    public Node getTarget() {
        return target;
    }

    /**
     * @param target the target to set
     */
    public void setTarget(Node target) {
        this.target = target;
    }

    /**
     * @return the value
     */
    public double getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(double value) {
        this.value = value;
    }

    /**
     * @return the nodesPath
     */
    public Map<String, NodeInfo> getNodesPath() {
        return nodesPath;
    }

    /**
     * @param nodesPath the nodesPath to set
     */
    public void setNodesPath(Map<String, NodeInfo> nodesPath) {
        this.nodesPath = nodesPath;
    }
}