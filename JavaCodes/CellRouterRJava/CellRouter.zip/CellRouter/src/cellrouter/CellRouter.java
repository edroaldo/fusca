public class CellRouter {
    private CommandLine cmd = null;
    private Options options = null;
    private String file;
    //private String fileHGNC;
    // public boolean checkArgs(String args[]){
    //     try{
    //         options = new Options();
    //         options.addOption("NET", true, "edge-weigthed network");
    //         options.addOption("C", false, "Create flow network");
    //         options.addOption("source", true, "source");
    //         options.addOption("sink", true, "sink");
    //         options.addOption("topPaths", true, "include only the top paths with the lowest cost");
    //         options.addOption("out", true, "Output folder");
    //         options.addOption("f", true, "filename");
    //         CommandLineParser parser = new PosixParser();
    //         this.cmd = parser.parse(options, args);
    //         return true;
    //     }catch(Exception e){
    //         System.err.println(e.getMessage());
    //         System.exit(1);
    //     }
    //     return false;
    // }
// OUT_DIR <- '/home/rafael/Desktop/biocomp/package/fusca/fusca/results/paths'
// NET <- '/home/rafael/Desktop/biocomp/package/fusca/fusca/results/paths/cell_edge_weighted_network.txt'
// network <- 'Cells_FlowNetwork'
// source <- 'cell_sources.txt'
// sink <- 'cell_sinks.txt'
// topPaths <- '25'
// -NET $NET -source $source -sink $sink -topPaths $topPaths -out $OUT_DIR -C -f $network
    public void runAnalysis(String NET, String source, String sink, int topPaths, String out, String C, String f) throws Exception, IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        // file = cmd.getOptionValue("NET");
        String file = NET;
        // if(cmd.hasOption("C")){
        if(C == "C"){
            createFlowNetwork(f, out, topPaths, source, sink, file);
            // System.exit(0);
        }
    }
    public void createFlowNetwork(String filename, String dir, int top, String cellSources, String cellSinks, String file) throws IOException{
        // System.out.println("Creating flow network...");
        // String filename = cmd.getOptionValue("f");
        // String dir = cmd.getOptionValue("out");
        // int top = Integer.valueOf(cmd.getOptionValue("topPaths"));
        // String cellSources = cmd.getOptionValue("source");
        // String cellSinks = cmd.getOptionValue("sink");
        Set<String> sourceCells = new LinkedHashSet(CellRouterUtils.getSourcesSinks(cellSources));
        Set<String> sinkCells = new LinkedHashSet(CellRouterUtils.getSourcesSinks(cellSinks));
        //Node source = new Node(cmd.getOptionValue("source"));
        //Node sink = new Node(cmd.getOptionValue("sink"));
        NetworkFlow net = new NetworkFlow();
        InputOutput io = new InputOutput();
        io.getNetworkData(file);
        List<Double> weigths = io.getWeights();
        Map<Integer, Map<String, Edge>> allPathsNet = new LinkedHashMap();
        Map<String, Node> network = new LinkedHashMap();
        //source.setSymbol(source.getName());
        //sink.setSymbol(sink.getName());
        //System.out.println(source);
        //System.out.println(sink);
        List<Node> sources = new ArrayList();
        List<Node> sinks = new ArrayList();
        for(String s: sourceCells){
            Node tmp = new Node(s);
            tmp.setSymbol(s);
            sources.add(tmp);
        }
        for(String s: sinkCells){
            Node tmp = new Node(s);
            tmp.setSymbol(s);
            sinks.add(tmp);
        }
        net.createNetwork(sources, sinks, network, io.getFrom(), io.getTo(), weigths);
        net.mappingNameToId(network);
        net.compute(network, allPathsNet);
        Map<String, Node> subnet = new LinkedHashMap();
        Map<Integer, List<Edge>> pathsSubnet = net.buildSubnet(network, //revise this function...
                subnet, allPathsNet);
        List<String> pathsFlow = new ArrayList();
        for (Integer path : pathsSubnet.keySet()) {
            String pathFlowAsString = CellRouterUtils.convertPath2String(pathsSubnet.get(path), true);
            pathsFlow.add(pathFlowAsString);
        }
        String pathsName = filename + "_paths.ser";
        Serialization.serialize(pathsFlow, dir + pathsName);
        List<Path> allPaths = CellRouterUtils.convertString2Paths(pathsFlow);
        //Collections.sort(allPaths, (Path p1, Path p2) -> Double.compare(p1.cost, p2.cost));
        Collections.sort(allPaths, (Path p1, Path p2) -> Double.compare(p1.flow, p2.flow));
        //Collections.sort(allPaths, Collections.reverseOrder());
        //List<Path> topPaths = allPaths.subList(0, 100);
        //List<Path> topPaths = allPaths.subList(0, top);
        //CellRouterUtils.savePaths(topPaths, filename + "_top_100_paths.txt");
        CellRouterUtils.savePaths(allPaths, filename + "_all_paths.txt");
        Map<String, Node> cellSubnet = CellRouterUtils.createNetworkFromPaths(CellRouterUtils.convertPaths2String(allPaths));
        Map<String, Double> cellFlows = CellRouterUtils.getTotalFlow(cellSubnet);
        //Map<String, Node> topPathsCellSubnet = CellRouterUtils.createNetworkFromPaths(CellRouterUtils.convertPaths2String(topPaths));
        //Map<String, Double> topPathsCellFlows = CellRouterUtils.getTotalFlow(topPathsCellSubnet);
        CellRouterUtils.saveSubNet(cellSubnet, filename+"_all_paths_subnet.txt");
        CellRouterUtils.saveFlows(cellFlows, filename + "_all_paths_totalFlow.txt");
        //CellRouterUtils.saveSubNet(topPathsCellSubnet, filename+"_top_paths_subnet.txt");
        //CellRouterUtils.saveFlows(topPathsCellFlows, filename + "_top_paths_totalFlow.txt");
        List<String> Rscripts = new ArrayList();
        //String topPathsSubnetGML = RJava.createScriptExportGML(filename+"_top_paths_subnet", filename + "_top_paths_totalFlow");
        String subnetGML = RJava.createScriptExportGML(filename+"_all_paths_subnet", filename + "_all_paths_totalFlow");
        //Rscripts.add(topPathsSubnetGML);
        Rscripts.add(subnetGML);
        String scriptName = filename + "_scripts" + ".R";
        CellRouterUtils.combineFiles(Rscripts, scriptName);
        // Talvez de erro aqui porque tá chamando o prompt.
        try {
            Runtime.getRuntime().exec("R --slave --no-save CMD BATCH " + scriptName);
        } catch (IOException error) {
            System.out.println(error.getMessage());
        }
    }
}
