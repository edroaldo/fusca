/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cellrouter;
//import org.rosuda.JRI.Rengine;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


/**
 *
 * @author edroaldo
 */
/*
class Console implements RMainLoopCallbacks{
    public void rWriteConsole(Rengine re, String text, int oType) {
        System.out.print(text);
    }
    
    public void rBusy(Rengine re, int which) {
        System.out.println("rBusy("+which+")");
    }
    
    public String rReadConsole(Rengine re, String prompt, int addToHistory) {
        //System.out.print(prompt);
        //try {
        //    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        //    String s=br.readLine();
        //    return (s==null||s.length()==0)?s:s+"\n";
        //} catch (Exception e) {
        //    System.out.println("jriReadConsole exception: "+e.getMessage());
        //}
        return null;
    }
    
    public void rShowMessage(Rengine re, String message) {
        System.out.println("rShowMessage \""+message+"\"");
    }
	
    public String rChooseFile(Rengine re, int newFile) {
	FileDialog fd = new FileDialog(new Frame(), (newFile==0)?"Select a file":"Select a new file", (newFile==0)?FileDialog.LOAD:FileDialog.SAVE);
	fd.show();
	String res=null;
	if (fd.getDirectory()!=null) res=fd.getDirectory();
	if (fd.getFile()!=null) res=(res==null)?fd.getFile():(res+fd.getFile());
	return res;
    }
    
    public void rFlushConsole(Rengine re) {
    }

    public void rLoadHistory(Rengine re, String filename) {
    }

    public void rSaveHistory(Rengine re, String filename) {
    }
}*/

public class RJava {
    public RJava(){
    
    }
    
    public static String createScriptExportGML(
            String filename_subnet,
            String filename_totalFlow) {

        String scriptName = filename_subnet + "_exportGML.R";
        String file_subnet = "\'" + filename_subnet + ".txt\'";
        String file_totalFlow = "\'" + filename_totalFlow + ".txt\'";
        String write_1 = "\'" + filename_subnet + ".gml" + "\'";
        try {
            File f = new File(scriptName);
            if (!f.exists()) {
                f.createNewFile();
            }
            FileWriter fw = new FileWriter(f.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            //bw.write("library(gplots);\n");
            //bw.write("library(ggplot2);\n");
            //bw.write("library(grid); \n");
            //bw.write("library(reshape); \n");
            //bw.write("library(reshape2); \n");
            //bw.write("library(plyr); \n");
            //bw.write("library(RColorBrewer); \n");
            bw.write("library(igraph); \n");
            //bw.write("library(Vennerable); \n");
            
            bw.write("subnet <- read.table(" + file_subnet + ", sep='\t', header = TRUE);\n");
            bw.write("totalFlow <- read.table(" + file_totalFlow + ", sep='\t', header = TRUE);\n");
            bw.write("colnames(subnet) <- c('from', 'to', 'weight');\n");
            bw.write("iG <- graph.data.frame(subnet, directed=FALSE);\n");
            bw.write("V(iG)$label <- V(iG)$name;\n");
            bw.write("V(iG)[as.vector(totalFlow$cell)]$totalFlows <- totalFlow$flows;\n");
            bw.write("V(iG)$degree <- igraph::degree(iG);\n");
            bw.write("neighS <- V(induced.subgraph(graph=iG,vids=unlist(neighborhood(graph=iG,order=1,nodes='s'))))$name;\n");
            bw.write("neighT <- V(induced.subgraph(graph=iG,vids=unlist(neighborhood(graph=iG,order=1,nodes='t'))))$name;\n");
            bw.write("V(iG)$props = rep(\"INTER\", length(V(iG)$name));\n");
            bw.write("V(iG)[match(neighS, V(iG)$name)]$props = \"SOURCE\";\n");
            bw.write("V(iG)[match(neighT, V(iG)$name)]$props = \"TARGET\";\n");
            bw.write("iG2 <- delete.vertices(iG, c('s','t'));\n");
            bw.write("write.graph(iG2," + write_1 + ", format = 'gml');\n");
            bw.write("#--------------------------------------------------------------------------\n");
            bw.close();
        } catch (IOException io) {
            System.out.println(io.getMessage());
        }
       return scriptName;
    }
}
